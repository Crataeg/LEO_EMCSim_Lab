本压缩包包含根据《附图清单（第三版）》生成的 10 张可编辑矢量图（SVG）及对应 PNG 预览图。
1. SVG 为可编辑矢量格式，可直接导入 Microsoft Visio 继续编辑。
2. 若需要更接近正式专利附图风格，可在 Visio 中统一改为更细线宽、去灰阶、调整字体。
3. 公式与参数名采用交底书第三版口径：Erep、AF、Lsys、Kconv、Veq、Peq、Ssens、Margin。
